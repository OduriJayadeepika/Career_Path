const express = require("express");
const app = express();
const router = express.Router();
const jwt = require("jsonwebtoken");
const userModel = require("../models/userModel");

router.get("/" , async function Loggedin(req, res) {
    try {
      const userToken = req.cookies.token;
      const result = jwt.verify(userToken, "Secret")
      console.log(result);
      
      if (!userToken) {
        return res.status(401).json({ message: "Unauthorized: No token provided." });
      }
  
      const user = await userModel.findOne({ email : userToken.email });
      if (!user) {
        return res.status(401).json({ message: "Unauthorized: Invalid token." });
      }
      res.send(true)
    } catch (error) {
        console.log(error);
        
      res.status(500).json({ message: "Internal Server Error" });
    }
  }
)
  module.exports = router